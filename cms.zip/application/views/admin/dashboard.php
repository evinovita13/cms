<h1>selamat datang dihalaman dashboard</h1>
<?= $this->session->userdata('nama'); ?>